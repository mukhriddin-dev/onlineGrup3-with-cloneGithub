import React from 'react';

const Navbar = () => {
    return (
        <div className={"navbar"}>
            <h3>Github App</h3>
        </div>
    );
};

export default Navbar;
