import React from 'react';

const Card = () => {
    return (
        <div className={"card"}>
            
        </div>
    );
};

export default Card;
