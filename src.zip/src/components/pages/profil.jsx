import React from 'react';

const Profil = () => {
    return (
        <div className={"profil"}>
             <h2>Profil</h2>
        </div>
    );
};

export default Profil;
